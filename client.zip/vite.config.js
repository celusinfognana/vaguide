
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  base: '/vateam/',
  server: {
    port: 3000,
    proxy: {
      '/api': {
        target: 'https://demomyapp.com/vaserver/',
        changeOrigin: true,
      },
    },
  }
});
